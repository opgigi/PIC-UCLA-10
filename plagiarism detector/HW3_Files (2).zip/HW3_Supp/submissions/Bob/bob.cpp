#include<iostream>

void print(int low, int up) {



  for(int i = 0; i <= up; ++i){
    std::cout << i;
  }


}

int main(){
  
  print(3, 30);

  return 0;
}